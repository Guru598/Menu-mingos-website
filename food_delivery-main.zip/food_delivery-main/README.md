# food_delivery

I Create Full Stack Food Delivery Website In React JS, MongoDB, Express, Node JS & Stripe
complete food ordering website / app using React JS, MongoDB, Express, Node JS and Stripe payment gateway. In this Full Stack Food delivery app project we will create the Frontend website, Admin Panel and Backend server. 
We will create the user authentication system so that anyone can create an account and login this food order website.
We will create the shopping cart functionality so that user can add food items in their cart and order food from this app. We will also integrate the Stripe payment gateway to place the order and with online payment. Then we will create the order status update features also.
 
![1722576618822](https://github.com/user-attachments/assets/3b0f10b7-dcca-4afd-acaa-61d1cc842406)
![1722576618532](https://github.com/user-attachments/assets/a1fd233a-20e5-413c-a26a-5b3c553f6570)
![1722576615830](https://github.com/user-attachments/assets/62979ae3-2876-444c-8982-58e81e682b37)
![1722576622132](https://github.com/user-attachments/assets/1e013722-1b11-4f66-b53a-9f5ef7325943)
![1722576622077](https://github.com/user-attachments/assets/86865f6f-6bdf-4581-8089-23e3c03af013)
![1722576621290](https://github.com/user-attachments/assets/021a5175-87bf-460f-aae7-8198e6d7e890)
![1722576621147](https://github.com/user-attachments/assets/c5751cf1-5575-40d8-8051-206bfd274ac6)
![1722576620360](https://github.com/user-attachments/assets/2ecb23dd-9e7b-4924-b78d-072787980cf2)
